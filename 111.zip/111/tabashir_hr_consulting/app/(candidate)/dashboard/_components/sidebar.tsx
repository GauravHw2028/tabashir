"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  Briefcase,
  ClipboardList,
  Heart,
  FileText,
  Sparkles,
  Video,
  DollarSign,
  Info,
  MessageCircle,
  BookOpen,
  User,
  LogOut,
} from "lucide-react"
import { onLogout } from "@/actions/auth"

export function Sidebar() {
  const pathname = usePathname()

  const isActive = (path: string) => {
    return pathname === path
  }

  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", href: "/dashboard" },
    { icon: Briefcase, label: "Jobs", href: "/jobs" },
    { icon: ClipboardList, label: "Applied Jobs", href: "/applied-jobs" },
    { icon: Heart, label: "Liked Jobs", href: "/liked-jobs" },
    { icon: FileText, label: "Resume", href: "/resume" },
    { icon: Sparkles, label: "AI Job Apply", href: "/ai-job-apply" },
    { icon: Video, label: "Interview Training", href: "/interview-training" },
    { icon: Info, label: "Service Details", href: "/service-details" },
    { icon: MessageCircle, label: "Whatsapp Community", href: "/whatsapp-community" },
    { icon: BookOpen, label: "Free Courses", href: "/free-courses" },
  ]

  return (
    <div className="h-full w-[250px] bg-white border-r flex flex-col rounded-lg p-2">
      <div className="p-4 border-b">
        <h1 className="text-xl font-bold text-gray-900">TABASHIR</h1>
      </div>

      <div className="flex-1 overflow-auto py-4">
        <nav className=" px-2">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center px-2 py-2 mb-2 text-base font-medium rounded-md ${
                isActive(item.href) ? "blue-gradient text-white" : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <item.icon className="mr-3 h-5 w-5" />
              {item.label}
            </Link>
          ))}
        </nav>
      </div>

      <div className="p-4 border-t">
        <Link
          href="/account"
          className="flex items-center px-2 py-2 text-sm rounded-md text-gray-700 hover:bg-gray-100"
        >
          <User className="mr-3 h-5 w-5" />
          Account
        </Link>
        <button onClick={() =>{
          onLogout("/candidate/login")
        }}  className="flex items-center px-2 py-2 mt-2 text-sm rounded-md text-red-500 hover:bg-gray-100 w-full text-left">
          <LogOut className="mr-3 h-5 w-5" />
          Logout
        </button>
      </div>
    </div>
  )
}
