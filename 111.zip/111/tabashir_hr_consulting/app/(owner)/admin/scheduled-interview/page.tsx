export default function ScheduledInterviewPage() {
  return (
    <div className="p-6 text-gray-900">
      <h1 className="text-2xl font-bold mb-6">Scheduled Interviews</h1>
      <p>This page is under construction.</p>
    </div>
  )
}
